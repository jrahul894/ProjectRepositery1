//package com.app.Service;
//
//import javax.transaction.Transactional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.app.Repositery.BookingRepositery;
//
//@Service
//@Transactional
//public class BookingServiceImpl implements BookingService {
//@Autowired
//private BookingRepositery booking;
//}
