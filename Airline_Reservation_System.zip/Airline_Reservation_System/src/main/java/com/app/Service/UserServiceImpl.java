package com.app.Service;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.Dto.ApiResponse;
import com.app.Dto.UserDto;
import com.app.Entities.User;
//import com.app.Repositery.PassengerRepositery;
import com.app.Repositery.UserRepositery;

@Service
@Transactional
public class UserServiceImpl implements UserService {
//	@Autowired
//	private PassengerRepositery passenger;
	@Autowired
	private UserRepositery repo;
	@Autowired
	private ModelMapper modelMapper;

	@Override
	public ApiResponse AddUser(UserDto user) {
        User newUser=modelMapper.map(user,User.class);
		 repo.save(newUser);
		return  new ApiResponse("User "+newUser.getUserId() +newUser.getFirstName() + newUser.getLastName() + " Registration Successfully");
	
	}
}
