package com.app.Dto;

public class FlightFilter {

}
