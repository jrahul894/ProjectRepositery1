package com.app.Entities;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table
@Data
@NoArgsConstructor
@AllArgsConstructor

public class Flight {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "CustomStringIdGenerator1")
	@GenericGenerator(name = "CustomStringIdGenerator1", strategy = "com.app.Entities.CustomStringIdGenerator1")
	private String flightId;
	
	private String airlineName;

	
	private Integer economyClassSeat;

	
	private Integer businessClassSeat;

	
	private Integer firstClassSeat;

	private Integer checkingBaggageCapacity;

	private Integer cabinBaggageCapacity;

    private Double price;

	private String scheduledFlight;
//    @OneToMany(mappedBy = "flight",  cascade = CascadeType.ALL,fetch = FetchType.LAZY,orphanRemoval = true)
//    private List<Passenger> passengers;

	
//	// helper method
//	public void AddPassenger(Passenger p1) {
//        passengers.add(p1);
//        p1.setFlight(this);
//        
//	}
//
//	public void RemovePassenger(Passenger p1) {
//		   passengers.remove(p1);
//		   p1.setFlight(null);
//	}
}
