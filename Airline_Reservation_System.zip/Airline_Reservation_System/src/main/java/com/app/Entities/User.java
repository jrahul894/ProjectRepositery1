package com.app.Entities;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import lombok.*;

@Entity
@Table(name="user")
@AllArgsConstructor
@Setter
@Getter
@ToString
@NoArgsConstructor
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "CustomStringIdGenerator2")
	@GenericGenerator(name = "CustomStringIdGenerator2", strategy = "com.app.Entities.CustomStringIdGenerator2")
	private String userId;
	
	private String firstName;
	
	private String lastName;
	@Column(unique = true,nullable=false)
	private String email;
	
	private String password;
	@Column(unique = true,nullable=false)
	private String phoneNo;
	
	private String role;
	
	private LocalDate dateOfBirth;
//	@OneToMany()
//	private List<Booking>bookingList;
}
