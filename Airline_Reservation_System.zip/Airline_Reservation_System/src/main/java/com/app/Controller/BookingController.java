//package com.app.Controller;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.app.Service.BookingService;
//
//@RestController
//public class BookingController {
//@Autowired
//private BookingService booking; 
//}
